package com.backendrumba.rumba_music.model;

public class PlayMessage {
    private Long songId;
    private String roomCode;

    public PlayMessage(Long songId, String roomCode) {
        this.songId = songId;
        this.roomCode = roomCode;
    }

    // Getters y setters
}
