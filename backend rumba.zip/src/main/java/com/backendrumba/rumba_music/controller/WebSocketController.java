package com.backendrumba.rumba_music.controller;

import com.backendrumba.rumba_music.model.PlayMessage;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class WebSocketController {

    @MessageMapping("/play")
    @SendTo("/topic/play")
    public PlayMessage sendPlayMessage(PlayMessage message) {
        return message;  // Enviar el mensaje a todos los clientes suscritos a /topic/play
    }
}

