package com.backendrumba.rumba_music;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RumbaMusicApplication {

	public static void main(String[] args) {
		SpringApplication.run(RumbaMusicApplication.class, args);
	}

}
